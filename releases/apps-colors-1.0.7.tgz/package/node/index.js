/* @apps/colors — every colour in apps/, as roles (see README.md).

   CSS:  import '@apps/colors/colors.css' and '@apps/colors/theme.css' (the kit does it).
   JS:   ROLES, THEMES and cssVar('chart-1') for code that hands colours to a canvas or SVG;
         it passes var(--role), never a value, so skin and mode keep working. */
export { contrast, flatten, luminance, parse, rgb } from './colour.js';
export { colorsCss, themeCss } from './css.js';
export { cssVar } from './css-var.js';
export { faviconSvg } from './favicon.js';
export {               runGate } from './gate.js';
export {
  EFFECTS,
              
  MODES,
            
  ROLES,
            
  SKINS,
            
  THEMES,
             
                
} from './roles.js';
