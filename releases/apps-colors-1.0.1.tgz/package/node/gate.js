import { contrast, flatten } from './colour.js';
import {            THEMES,               } from './roles.js';

/* The contrast gate, run on the role table itself (no browser): every pair a component can
   draw is measured in every skin × mode, against the WORST case under translucent surfaces
   (glass: the page canvas plus the backdrop wash at its peak, blur ignored). Disabled roles
   are exempt (WCAG 1.4.3 excludes inactive components).

   Text 4.5:1 (1.4.3). Input boundaries, the focus colour and chart series 3:1 (1.4.11). */

                          
                  
               
                
               
 

                       
           
                      
               
                                                                                              
                 
  

/* What sits on what. `on` is a stack painted over the page, bottom first after the canvas:
   ['surface', 'primary'] = a primary button on a card. */
const CHECKS                   = [
  // text on every surface
  ...(['fg', 'fg-muted', 'fg-subtle']         ).flatMap((t) =>
    (['canvas', 'surface', 'raised', 'sunken', 'overlay', 'bar']         ).map(
      (s) => [t, [s], 4.5]         ,
    ),
  ),
  // text on interaction washes (a hovered / pressed / selected row or item)
  ...(['hover', 'pressed', 'selected']         ).map((w) => ['fg', ['surface', w], 4.5]         ),
  ['fg-muted', ['surface', 'hover'], 4.5],
  // links and brand text
  ['link', ['canvas'], 4.5],
  ['link', ['surface'], 4.5],
  ['link-hover', ['surface'], 4.5],
  ['brand', ['surface'], 4.5],
  ['brand', ['surface', 'brand-soft'], 4.5],
  ['brand', ['surface', 'selected'], 4.5],
  // status and market text, plain and on its own wash
  ...(['success', 'warning', 'danger', 'info', 'up', 'down']         ).flatMap((s) => [
    [s, ['canvas'], 4.5]         ,
    [s, ['surface'], 4.5]         ,
    [s, ['surface', `${s}-soft`        ], 4.5]         ,
  ]),
  // body text on a tone's wash (Notice, ErrorState), on a card and straight on the page
  ...(['success', 'warning', 'danger', 'info', 'brand']         ).flatMap((s) =>
    (['fg', 'fg-muted']         ).flatMap((t) => [
      [t, ['surface', `${s}-soft`        ], 4.5]         ,
      [t, ['canvas', `${s}-soft`        ], 4.5]         ,
    ]),
  ),
  ['flat', ['surface'], 4.5],
  // every button level, at rest, hovered and pressed, on a card
  ...(['primary', 'primary-hover', 'primary-active']         ).map(
    (b) => ['on-primary', ['surface', b], 4.5]         ,
  ),
  ...(['secondary', 'secondary-hover', 'secondary-active']         ).map(
    (b) => ['on-secondary', ['surface', b], 4.5]         ,
  ),
  ...(['neutral', 'neutral-hover', 'neutral-active']         ).map(
    (b) => ['on-neutral', ['surface', b], 4.5]         ,
  ),
  ['on-outline', ['surface'], 4.5],
  ...(['outline-hover', 'outline-active']         ).map(
    (b) => ['on-outline', ['surface', b], 4.5]         ,
  ),
  ['on-ghost', ['surface'], 4.5],
  ...(['ghost-hover', 'ghost-active']         ).map(
    (b) => ['on-ghost', ['surface', b], 4.5]         ,
  ),
  ...(['danger-solid', 'danger-solid-hover', 'danger-solid-active']         ).map(
    (b) => ['on-danger', ['surface', b], 4.5]         ,
  ),
  ...(['success-solid', 'success-solid-hover', 'success-solid-active']         ).map(
    (b) => ['on-success', ['surface', b], 4.5]         ,
  ),
  // initials on an avatar
  ...([1, 2, 3, 4, 5, 6]         ).map(
    (n) => ['fg', ['surface-solid', `avatar-${n}`        ], 4.5]         ,
  ),
  // Photo's corner chip: what sits over a photograph (the "Best match" badge, Retake, the select
  // checkbox) sits on a solid surface, so it is measured on that, not on the picture
  ['fg', ['surface-solid'], 4.5],
  ['brand', ['surface-solid', 'brand-soft'], 4.5],
  ...(['neutral', 'neutral-hover', 'neutral-active']         ).map(
    (b) => ['on-neutral', ['surface-solid', b], 4.5]         ,
  ),
  ['border-input', ['surface-solid'], 3],
  // boundaries and the focus colour
  ['border-input', ['canvas'], 3],
  ['border-input', ['surface'], 3],
  ['focus', ['canvas'], 3],
  ['focus', ['surface'], 3],
  // text straight on the page over the static backdrop washes, and over the busiest frame of
  // the shader scene (its palette at full strength, then the page-coloured scrim)
  // (the backdrops are the glass skin's: enterprise's smallest, subtlest text is not held to them)
  ...(['fg', 'fg-muted', 'fg-subtle']         ).flatMap((t) => {
    const skin = t === 'fg-subtle' ? ('glass'         ) : undefined;
    return [
      ...([1, 2, 3]         ).map(
        (n) => [t, ['canvas', `backdrop-${n}`        ], 4.5, skin]         ,
      ),
      ...(['shader-a', 'shader-b', 'shader-c']         ).map(
        (c) => [t, ['canvas', c, 'shader-scrim'], 4.5, skin]         ,
      ),
    ];
  }),
  // sea glass: text on the paper and on every glass tint (the flat fallback fill)
  ...(['fg', 'fg-muted']         ).flatMap((t) => [
    [t, ['seaglass-paper'], 4.5]         ,
    ...([0, 1, 2, 3, 4, 5, 6]         ).map(
      (n) => [t, ['seaglass-paper', `seaglass-${n}`        ], 4.5]         ,
    ),
  ]),
  ...(['link', 'link-hover']         ).map(
    (t) => [t, ['seaglass-paper', 'seaglass-0'], 4.5]         ,
  ),
  // the heat ramp's four filled steps (heat-0 is an empty cell, outlined)
  ...([1, 2, 3, 4]         ).flatMap((n) => [
    [`heat-${n}`        , ['canvas'], 3]         ,
    [`heat-${n}`        , ['surface'], 3]         ,
  ]),
  // chart series
  ...([1, 2, 3, 4, 5, 6, 7, 8]         ).flatMap((n) => [
    [`chart-${n}`        , ['canvas'], 3]         ,
    [`chart-${n}`        , ['surface'], 3]         ,
  ]),
];

export function runGate()            {
  const failures            = [];
  for (const [key, theme] of Object.entries(THEMES)                                           ) {
    const page = [theme.roles.canvas, theme.backdropPeak];
    for (const [fg, on, need, only] of CHECKS) {
      if (only && !key.startsWith(only)) continue;
      const bg = flatten([...page, ...on.map((r) => theme.roles[r])]);
      const text = flatten([bg, theme.roles[fg]]);
      const ratio = contrast(text, bg);
      if (ratio < need) {
        failures.push({ theme: key, pair: `${fg} on ${on.join(' > ')}`, ratio, need });
      }
    }
  }
  return failures;
}
